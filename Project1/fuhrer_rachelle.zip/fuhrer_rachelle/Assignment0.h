#ifndef CSE168_ASSIGNMENT_0_H_INCLUDED
#define CSE168_ASSIGNMENT_0_H_INCLUDED

class Assignment0
{

public:
	Assignment0();
	~Assignment0();

	void makeSpiralScene();
	void makeSpirographScene();
};

#endif // CSE168_ASSIGNMENT_0_H_INCLUDED