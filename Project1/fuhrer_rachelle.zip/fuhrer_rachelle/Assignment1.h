#ifndef CSE168_ASSIGNMENT_1_H_INCLUDED
#define CSE168_ASSIGNMENT_1_H_INCLUDED

class Assignment1
{

public:
	Assignment1();
	~Assignment1();

	void makeBunnyScene();
	void makeSphereScene();
	void makeSmoothSphereScene();
	void makeTeapotScene();
	void makeSimpleTriangleScene();
	void makeDragonScene();
	void makeBLPatchScene();
};

#endif // CSE168_ASSIGNMENT_1_H_INCLUDED